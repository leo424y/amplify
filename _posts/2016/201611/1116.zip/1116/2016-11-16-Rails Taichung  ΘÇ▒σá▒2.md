---
layout: post
comments: true
title: Rails Taichung  週報
---

# headquarters
Rails Taichung 週報

每週提供最新鮮趣味的工程師議題!

Rails Taichung  週報 會在 GMT+8 時區的每個禮拜一早上 7:00 出刊，每一期會從目前的 curator 名單中選出當期的內容。你也可以瀏覽一下[前幾期的內容]()。

以下是目前的 curator 陣容

* @fruitcake0525 -
* @kenny -
* @leo424y - 來做形象網頁吧! https://leo424y.github.io/land

大家也可以關注我們的 [官網](http://rails-taichung.com)  [Facebook 社團](https://www.facebook.com/groups/RORTaichung/)、[Twitter]()、[GitHub](https://github.com/railstaichung/rails-taichung) 或[微博]()，有很多 Weekly 看不到的內容。有任何建議或疑問也可以來 [Gitter](https://gitter.im/railstaichung/) 聊聊，歡迎亂入

以 Rails 為出發點，致力於解決專業與業餘之資訊不對稱

* 查看公告和待辦事項請至 [GitHub Issues](https://github.com/railstaichung/headquarters/issues)。
* 討論和話唬爛請至 [Slack](https://rortc.herokuapp.com/)。

Join us on [Facebook](https://www.facebook.com/groups/RORTaichung/) and [Twitter]().


Rails Taichung  週報 會在 GMT+8 時區的每個禮拜一早上 7:00 出刊，每一期會從目前的 curator 名單中選出當期的內容。你也可以瀏覽一下[前幾期的內容]()。

以下是目前的 curator 陣容：

* @fruitcake0525 -
* @kenny -
* @leo424y - 來做形象網頁吧! https://leo424y.github.io/land

大家也可以關注我們的 [官網]()  [Facebook 社團]()、[Twitter]()、[GitHub](https://github.com/railstaichung/rails-taichung) 或[微博]()，有很多 Weekly 看不到的內容。有任何建議或疑問也可以來 [Gitter](https://gitter.im/railstaichung/) 聊聊，歡迎亂入

以 Rails 為出發點，致力於解決專業與業餘之資訊不對稱

* 查看公告和待辦事項請至 [GitHub Issues](https://github.com/railstaichung/headquarters/issues)。
* 討論和話唬爛請至 [Slack]()。

Join us on [Facebook]() and [Twitter]().



CodeTengu Weekly 會在 GMT+8 時區的每個禮拜一早上 10:00 出刊，每一期會從目前的 curator 名單中選出三位來負責當期的內容。會提前一、二個禮拜在 [GitHub Issues](https://github.com/codetengu/headquarters/issues) 公布每一期的 curator 名單。

按照慣例，我們會在每一期的發刊日前一天的晚上 22:00 截稿，負責當期內容的 curator 每人可以精選 5 則你覺得有價值的文章放進 Weekly 裡，主題和文章的難易度沒有限制，原創或是轉貼都可以。每一期的 curator 可以登入 [Curated](https://my.curated.co/codetengu/issues) 的後台，把你挑選的文章加入有你的名字的 Category 裡，然後加上幾句評論。

以下是目前的 curator 名單及各自擅長的領域，依照加入時間排序：

* [@](https://github.com/) -
* [@](https://github.com/) -
* [@](https://github.com/) -
* [@leo424y](https://github.com/leo424y) - 科技應用、教育、學習、有的沒的


以下是已退出的 curator 名單，依照離開時間排序：

*

特別感謝 [@rocavence](https://www.linkedin.com/in/rocavence) 設計的煞氣的 LOGO。

### CodeTengu Weekly 碼天狗週刊

CodeTengu Weekly 會在 GMT+8 時區的每個禮拜一早上 10:00 出刊，每一期會從目前的 curator 名單中選出三位來負責當期的內容，每個 curator 各自負責不同的領域。如果你在這一期沒有看到自已感興趣的東西，說不定下一期就會有了。你也可以瀏覽一下[前幾期的內容](http://link.codetengu.com/QSn0m4O?m=web)。

以下是目前的 curator 陣容：

* [@vinta](http://link.codetengu.com/mlvfhmM?m=web) - [I failed the Turing Test](http://link.codetengu.com/X635D17?m=web) - 科幻迷。最近在讀 [We Are Legion (We Are Bob)](http://link.codetengu.com/2IVFVd0?m=web)
* [@saiday](http://link.codetengu.com/vimDKmX?m=web) - [Imnotyourson](http://link.codetengu.com/Uni18Pu?m=web) - 買了文明帝國 6
* [@tzangms](http://link.codetengu.com/LBLJiLT?m=web) - [Oceanic / 人生海海](http://link.codetengu.com/qMGEA8p?m=web) - 衝動型購物
* [@fukuball](http://link.codetengu.com/iY5QVbk?m=web) - [ImFukuball](http://link.codetengu.com/HaxIgA2?m=web) - 婚後生活
* [@mingderwang](http://link.codetengu.com/jDUW1lM?m=web) - Ethereum enthusiast
* [@kako0507](http://link.codetengu.com/398vxbK?m=web) - 熱愛嘗試新事物的前端工程師
* [@chiahsien](http://link.codetengu.com/BLwd1Vh?m=web) - 我們在找 [iOS 工程師與其它人才](http://link.codetengu.com/ooh8vrl?m=web)，歡迎來跟我當同事
* [@hiroshiyui](http://link.codetengu.com/OWBhBRs?m=web) - 沒有人是一座孤島
* [@uranusjr](http://link.codetengu.com/4bNfDgy?m=web) - [Smaller Things](http://link.codetengu.com/3uLC1RI?m=web) - 不愛談技術的技術人，最近對做菜很有興趣
* [@kkdai](http://link.codetengu.com/d1xFtGI?m=web) - [態度萬歲](http://link.codetengu.com/4LjEZOG?m=web) - 喜歡 Golang 的略懂工程師
* [@yhsiang](http://link.codetengu.com/m9oMYfI?m=web)

大家也可以關注我們的 [Facebook](http://link.codetengu.com/KDdWR18?m=web)、[Twitter](http://link.codetengu.com/FJjLe3K?m=web)、[GitHub](http://link.codetengu.com/DvS6tcW?m=web) 或[微博](http://link.codetengu.com/yItgu1Q?m=web)，有很多 Weekly 看不到的內容。有任何建議或疑問也可以來 [Gitter](http://link.codetengu.com/HrcAViC?m=web) 聊聊，歡迎亂入 👺致力於解決開發者之間的資訊不對稱
