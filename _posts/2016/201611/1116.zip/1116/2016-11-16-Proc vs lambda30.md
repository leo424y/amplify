---
layout: post
comments: true
title: Proc vs lambda
---

[**_關於Ruby的學習:_**](http://www.evanlin.com/ruby-e9-97-9c-e6-96-bccodecademy-e5-ad-b8-e7-bf-92ruby-e7-9a-84-e5-bf-83-e5-be-97/)

* **Chapter 15: Blocks Procs 跟 Lambda差異**
    * 這一章節相當有趣，把三個容易搞錯的概念 Blocks Procs 與 Lambda來比較，這裡先把三種寫法都先寫一次
        * Block:
            * block_a = { DO_SOMETHING }

        * Proc:
            * proc_a = Proc.new {  DO_SOMETHING }

            * proc_a.call

        * Lambda:
            * lambda_a = lambda { DO_SOMETHING }

            * lambda_a.call

    * 接下來會把它們的不同與差異來詳述一下:
        * Proc 與 Lambda都是一種Block但是有一些差異~接下來會提到

        * 跟Block不同，Lambda與Proc都可以當成參數傳遞並使用 .call 來呼叫

        * Proc與Lambda都可以傳遞參數，但是Lambda會檢查參數的個數，但是Proc會把他裝成nil

        * Lambda的return 會回到caller，但是Proc直接回傳
            *

def batman_ironman_proc
victor = Proc.new { return “Batman will win!” }
victor.call
“Iron Man will win!”
end

puts batman_ironman_proc

**\#print Batman will win!**

def batman_ironman_lambda
victor = lambda { return “Batman will win!” }
victor.call
“Iron Man will win!”
end

puts batman_ironman_lambda
**\#print Iron Man will win!**

```
* 更多部分可以參考: [http://www.adamjonas.com/blog/procs-and-lambdas/](http://www.adamjonas.com/blog/procs-and-lambdas/)
```

* **Chapter 16: Object-Oriented Programming(I)**
    * 在物件導向的程式設計上面，根據[Wiki](http://zh.wikipedia.org/wiki/Ruby) 的說法是這樣子(等等會提到一些原因):
        * Ruby的繼承功能相當脆弱，儘管Ruby是一個物件導向語言，Ruby內的許多規則，卻使得子類別有可能不小心就覆寫了父型別的功能，在《The Ruby Programming Language》一書中，建議除非程式設計師對一個型別相當了解，否則盡可能不要使用繼承。

    * 關於繼承 (Inheritance)
        * Ruby只支援單一繼承..

        * Ruby在繼承上 Child 的constructor (Ruby叫做 initialize) 並不會呼叫Parent的 initialize.
            * 使用上只能自己加上 super或是使用 composition 的做法.. http://ruby.learncodethehardway.org/book/ex44.html

        * 關於變數在繼承上的應用
            * @ instance variable: 是個別class分開的..  但是child 卻無法存取parent 的instance variable (會得到 nil)

            * @@ class variable: 所有繼承體系的都會共用…  所以後面的不論是Parent還是Child 都會改寫到…..

            * 更多:
                * 可以看這篇 http://www.railstips.org/blog/archives/2006/11/18/class-and-instance-variables-in-ruby/

                * 或是這個問答 http://stackoverflow.com/questions/15773552/ruby-class-instance-variable-vs-class-variable

    * 更多可以參考以下文章:
        * http://www.railstips.org/blog/archives/2006/11/18/class-and-instance-variables-in-ruby/

        * http://rubylearning.com/satishtalim/ruby_inheritance.html

        * http://ruby.learncodethehardway.org/book/ex44.html

