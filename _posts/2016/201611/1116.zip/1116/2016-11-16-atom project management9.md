---
layout: post
comments: true
title: atom project management
---

@ 裝這麼久才發現 [project management](https://github.com/danielbrodin/atom-project-manager)

能在記錄已開的專案資料夾成為一個專案

好處是不必每次都要重開重加
記錄分頁的概念


