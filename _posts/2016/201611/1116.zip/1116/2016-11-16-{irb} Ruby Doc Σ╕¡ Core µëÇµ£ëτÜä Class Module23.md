---
layout: post
comments: true
title: {irb} Ruby Doc 中 Core 所有的 Class Module
---


全面解釋（太多不列＆略過 Error / IO 與輔助系列）

照 Doc 中的順序瀏覽

說明如何查 doc 與使用 doc

Range 的 .. 與 ... 的分別

