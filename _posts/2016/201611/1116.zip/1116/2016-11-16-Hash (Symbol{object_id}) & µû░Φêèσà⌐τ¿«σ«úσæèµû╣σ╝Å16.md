---
layout: post
comments: true
title: Hash (Symbol{object_id}) & 新舊兩種宣告方式
---

{:wer => 123 , :sdf => 234} #=> {:wer => 123 , :sdf => 234}
{wer:123 , sdf: 234} #=> {:wer => 123 , :sdf => 234}

人人.object_id 因時變動
除了symbol :symbol 建議當 key

#字元和冒號不能空白，後面數值可以
{a: 123, aa:223}.keys => [:a, :aa]
{a: 123, aa: 223}.values => [123, 223]

