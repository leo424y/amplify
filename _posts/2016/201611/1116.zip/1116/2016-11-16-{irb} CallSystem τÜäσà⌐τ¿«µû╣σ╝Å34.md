---
layout: post
comments: true
title: {irb} CallSystem 的兩種方式
---

：`command` 與 system(“command”)

