---
layout: post
comments: true
title: Top 10 Quick Rails Performance Wins
---

<!-- Author -->

by [Jason Lee](https://www.stationcode.net/blog/top-10-quick-rails-performance-wins?utm_content=buffer7d84b&utm_medium=social&utm_source=facebook.com&utm_campaign=buffer#)

---

<!-- Date/Time -->

Posted on Friday, Nov 04, 2016 11:43 PM

---

<!-- Preview Image -->![](https://f000.backblazeb2.com/file/StationCode/site/speed-1280.jpg "station code rails performance wins")


---

<!-- Post Content -->

We've been using and deploying Rails applications since 1.0. In the beginning, Rails performance was really looked down on and wasn't really defended. You used and deployed with it because of developer productivity. Over time things like caching, internal performance improvements, and overall server improvements have made Rails performance less and less of an issue.

