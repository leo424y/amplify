---
layout: post
comments: true
title: each 丟全部array值 each_with_index value連index
---


