---
layout: post
comments: true
title: 打字動畫 slack landing page 用的 js 特效
---
http://www.mattboldt.com/demos/typed-js/

