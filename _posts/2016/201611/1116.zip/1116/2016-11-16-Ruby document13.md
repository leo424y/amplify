---
layout: post
comments: true
title: Ruby document
---

Doc 的查法：
[RubyDoc 分三類 ](http://ruby-doc.org/)：
Core	：Ruby 預設載入
Std-lib	：內建，但須自行 require
Gem	：要自行安裝（gem i package_name）並 require
介紹 [Ruby Toolbox](https://www.ruby-toolbox.com/) 如何看排名和分類


