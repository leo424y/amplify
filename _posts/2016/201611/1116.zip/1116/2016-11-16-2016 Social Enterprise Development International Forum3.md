---
layout: post
comments: true
title: 2016 Social Enterprise Development International Forum
---

https://www.youtube.com/watch?v=GKUV5ADIG88

Chairman LePage, Mr. Verbal, Mr. Efremova, Legislator Karen Yu, Deputy Minister Kuo, distinguished guests and colleagues from Ministry of Labor, good morning. It is a pleasure having this opportunity to share our progress on amending the Company Act.

Started about 2 years ago, it is an ongoing project that will make a critical impact on all companies in Taiwan, including social enterprises. Based on the principles of deregulation and increasing transparency, we hope the new Company Act revision not only make companies’ operation more flexible but also facilitate the establishment and development of social enterprises.

In December 2014, we launched vTaiwan, an online platform that designed to bridge the government, the private sector, and civil society stakeholders using digital technology to deliberate regulations. The idea came from a proposal from the former Minister without Portfolio, Jaclyn Tsai, in a g0v hackathon.

The first issue tackled by vTaiwan was the idea of “closely-held limited-liability companies” (CLLCs; similar to Delaware LLCs). In the past, Company Act’s chapter on companies limited by shares was set up for large enterprises, although most of companies in Taiwan are listed as small-medium enterprises (SMEs). In order to maintain operational flexibility, many SMEs and newly established businesses choose to workaround the law, or even moving abroad to places like Cayman Islands. This had the unfortunate consequence of increasing company operation costs, causing more legal disputes, eroding tax base and hollowing out domestic law.

In order to solve these problems and formalize the regulation of CLLCs, we developed vTaiwan as the working platform — with Open Government as its principle — to unveil a series of discussions, both online and offline.

It took three months and involved thousands of viewers on livestream, hundreds of suggestions, and about 20 face-to-face contributors. Online public consultation took place from February to May 2015, then the consensus position was signed into law by parliament, which came into force on September 2015. To date, more than 300 companies have registered as CLLCs, proving the initial success of our methodologies.

Following the implementation of CLLCs, we went on to deliberate many topics publicly, including equity-based crowdfunding and regulation of electronic driver dispatch systems.

However, for the Company Law, the section on CLLCs was just a start. Its status as an exception could lead to misinterpretation of “strict by default, lenient by exception,” making it miss its legislative aim. And still, CLLCs need to change into non-closed companies limited by shares to be publicly listed, increasing the cost and uncertainty.

Besides that, the Company Act has other issues yet to deal with:
- Streamlining the company registration system
- Improving the flexibility of company autonomy mechanisms
- Increasing the effectiveness of accountability for company executives
- Recognizing companies with diverse goals, such as social missions

So, the next step is on other parts of the Company Act revision, starting with "foreign names" in last week’s deliberation, a consensus has emerged on simplifying the registration system and put foreign names as part of public disclosure.

Based on principles of openness and transparency, we will keep working on law adjustment to meet the needs of SMEs and newly established businesses. The logic and purpose of the whole policy making system is to accommodate the voice of SMEs that was often ignored or excluded. By yielding more participation space to academic and particle professionals, we would have a broader spectrum of discussions.

Furthermore, I really appreciate that the director of department of commerce from MOEA 李鎂 (Li Mei) voluntarily joined the online public consultation last week. In the future, we will gradually strengthen and expand the direct communication process between public sector and different stakeholders.

Take, for example, the needs of social enterprises. We understand that some stakeholders think the company act already works well on this regard, but some stakeholders think that we can amend the law to formally allow companies to consider social impact as important as financial returns to shareholders.

All these options can be considered and deliberated together; we are very much willing to conduct more opinion exchanges, sharing what we have learned within Taiwan and with our counterparts around the world.

Thanks for your listening; I look forward to more opportunities to work together, and I wish you a productive conference.
