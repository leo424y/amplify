puts Time.now
puts Time.now.class
puts Time.now.to_s.class
puts Time.now.to_s
puts Time.now.to_s.split(' ')[0]
puts Time.now.to_s.split(' ')[1]
puts Time.now.to_s.split(' ')[2]
