---
layout: post
comments: true
title: Social Media Link
---

Our Stack:

Ruby on Rails 4
Angular
Redis
Sidekiq
PostgreSQL
AWS
social networking APIs
elastic scaling techniques
other technologies for testing, monitoring, etc.

Desired Skills and Experience:

At least 3 years of Ruby on Rails development experience
Software development skills commensurate to the position; knowledge of Ruby on Rails and front end frameworks.
Linux
SQL
3rd party web APIs
Innovative mind, willingness to learn, independent thinking.
continuous integration
cloud deployment (AWS, Heroku)

