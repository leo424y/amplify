---
layout: post
comments: true
title: veterans ez info
---

[Veterans EZ Info](https://remoteok.io/remote-startups/veterans-ez-info)

[Software Developer](https://remoteok.io/remote-dev-jobs "Remote Software Developer Jobs"), [Ruby](https://remoteok.io/remote-ruby-jobs "Remote Ruby Jobs"), [Ruby](https://remoteok.io/remote-ruby-jobs "Remote Ruby Jobs"), [Digital Nomad](https://remoteok.io/remote-digital-nomad-jobs "Remote Digital Nomad Jobs")

**RUBY ON RAILS DEVELOPER**

VetsEZ is rapidly growing HealthCare IT consulting firm that designs, develops, and implements a wide range of healthcare IT solutions to federal and commercial customers. We have an opening for Ruby on Rails Developer for a very large multi - year federal government project at the Department of Veterans Affairs.  The incumbent will be an active participant in providing the development services necessary for enhancements to an existing web - based Clinician User Interface (CUI) system developed using Ruby on Rails and hosted in the Amazon cloud environment.

**Required skills and responsibilities:**


* Has working knowledge of healthcare business domain.

* Experience in using agile processes and industry lifecycle best practices.

* Has extensive practical experience with the techniques and approaches required in delivering Agile projects using a variety of technical skills to deliver products that are complex in nature.

* Design and develop software for Web applications, Application Program Interfaces (APIs) and Electronic Data Interchange (EDI).

* Capture functional requirements as Use Cases and accurately estimate level of effort to develop.

* Develop the features and capabilities as work items in Rational Team Concert.

* Work independently to identify solutions.

* Write object-oriented Web application/interface code conforming to established methodology and standards.

* Design and code software service components, units, and modules that meet project specifications and development schedules.

* Work closely with the project team to ensure that all technical project deliverables comply with customer standards and requirements.

* Develop and deliver automated build and automated publishing capabilities to schedule jobs and support continuous integration.

* Install, integrate, customize and validate user-defined requirements to CUI and maintain Section 508 and security compliance for the existing system.

* Troubleshoot problems and provide customer support for application issues.

* Applies high standards of quality to work completed.

* Is highly productive and performs well under pressure.

* Learns quickly and adapts easily to new challenges.

* Excellent communication and problem resolution skills.

* Currently has or is able to obtain Medium Level Security Clearance (MBI).

**Desirable Skills:**


* Experience with the Dept. of VA, tools, processes and frameworks.

* Experience with Rational Tools Suite is plus.

* Current VA access is preferred but not mandatory for this position.

* Knowledge of VA VIP and ProPath support would be considered a plus.

**Education/Experience:**


* Bachelors Degree in Computer Science/Engineering or equivalent.

* 3+ years of experience with Ruby on Rails.

* 5 - 7 years of relevant work experience.

This is primarily a telecommute position.  Occasional travel may be required.


