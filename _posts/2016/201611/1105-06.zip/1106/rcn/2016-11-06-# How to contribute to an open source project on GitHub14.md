---
layout: post
comments: true
title:  How to contribute to an open source project on GitHub
---

__[Davide Coppola](http://blog.davidecoppola.com/author/r00t/ "Posts by Davide Coppola")
__November 5, 2016
__[5 Comments](http://blog.davidecoppola.com/2016/11/howto-contribute-to-open-source-project-on-github/#comments)

__[Git](http://blog.davidecoppola.com/category/git/)

__[contribute](http://blog.davidecoppola.com/tag/contribute/), [contributing](http://blog.davidecoppola.com/tag/contributing/), [contribution](http://blog.davidecoppola.com/tag/contribution/), [example](http://blog.davidecoppola.com/tag/example/), [fork](http://blog.davidecoppola.com/tag/fork/), [GitHub](http://blog.davidecoppola.com/tag/github/), [guide](http://blog.davidecoppola.com/tag/guide/), [howto](http://blog.davidecoppola.com/tag/howto/), [open](http://blog.davidecoppola.com/tag/open/), [open source](http://blog.davidecoppola.com/tag/open-source/), [project](http://blog.davidecoppola.com/tag/project/), [step by step](http://blog.davidecoppola.com/tag/step-by-step/), [steps](http://blog.davidecoppola.com/tag/steps/), [tutorial](http://blog.davidecoppola.com/tag/tutorial/)

<iframe name="f378c2da59d037c" width="100px" height="1000px" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" title="fb:like Facebook Social Plugin" src="https://www.facebook.com/v2.0/plugins/like.php?app_id=&channel=http%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter%2Fr%2FfTmIQU3LxvB.js%3Fversion%3D42%23cb%3Df31fe43e600ee8%26domain%3Dblog.davidecoppola.com%26origin%3Dhttp%253A%252F%252Fblog.davidecoppola.com%252Ff3aa8720bb06324%26relation%3Dparent.parent&container_width=0&href=http%3A%2F%2Fblog.davidecoppola.com%2F2016%2F11%2Fhowto-contribute-to-open-source-project-on-github%2F&layout=button_count&locale=en_US&sdk=joey&width=100" style="border: none; visibility: visible; width: 77px; height: 20px;" class=""></iframe>

<iframe id="twitter-widget-0" scrolling="no" frameborder="0" allowtransparency="true" class="twitter-share-button twitter-share-button-rendered twitter-tweet-button" title="Twitter Tweet Button" src="http://platform.twitter.com/widgets/tweet_button.2dbd32894063b53338de1c1d4a747ea9.en.html#dnt=false&id=twitter-widget-0&lang=en&original_referer=http%3A%2F%2Fblog.davidecoppola.com%2F2016%2F11%2Fhowto-contribute-to-open-source-project-on-github%2F&size=m&text=How%20to%20contribute%20to%20an%20open%20source%20project%20on%20GitHub&time=1478396813900&type=share&url=http%3A%2F%2Fblog.davidecoppola.com%2F2016%2F11%2Fhowto-contribute-to-open-source-project-on-github%2F" style="position: static; visibility: visible; width: 63px; height: 20px;" data-url="http://blog.davidecoppola.com/2016/11/howto-contribute-to-open-source-project-on-github/"></iframe>

<iframe frameborder="0" hspace="0" marginheight="0" marginwidth="0" scrolling="no" style="position: static; top: 0px; width: 90px; margin: 0px; border-style: none; left: 0px; visibility: visible; height: 20px;" tabindex="0" vspace="0" width="100%" id="I0_1478396813133" name="I0_1478396813133" src="https://apis.google.com/u/0/se/0/_/+1/fastbutton?usegapi=1&size=medium&hl=en&origin=http%3A%2F%2Fblog.davidecoppola.com&url=http%3A%2F%2Fblog.davidecoppola.com%2F2016%2F11%2Fhowto-contribute-to-open-source-project-on-github%2F&gsrc=3p&jsh=m%3B%2F_%2Fscs%2Fapps-static%2F_%2Fjs%2Fk%3Doz.gapi.en.nmHsq_9V1yM.O%2Fm%3D__features__%2Fam%3DAQ%2Frt%3Dj%2Fd%3D1%2Frs%3DAGLTcCN5z8Jp-DINzl9GmIyJwcAXbfFTRg#_methods=onPlusOne%2C_ready%2C_close%2C_open%2C_resizeMe%2C_renderstart%2Concircled%2Cdrefresh%2Cerefresh%2Conload&id=I0_1478396813133&parent=http%3A%2F%2Fblog.davidecoppola.com&pfname=&rpctoken=16999956" data-gapiattached="true" title="+1"></iframe>

[inShare](javascript:void(0);)14

<iframe src="//www.redditstatic.com/button/button1.html?url=http%3A%2F%2Fblog.davidecoppola.com%2F2016%2F11%2Fhowto-contribute-to-open-source-project-on-github%2F" height="22" width="120" scrolling="no" frameborder="0"></iframe>

A step by step guide that will show you how to contribute to an open source project on GitHub, one of the most popular and used git repository hosting services.

![How to contribute to an open source project on GitHub](http://blog.davidecoppola.com/wp-content/uploads/2016/11/GitHub-logo-header.png "How to contribute to an open source project on GitHub")

GitHub is the home of many popular open source projects like Ruby on Rails, jQuery, Docker, Go and many others.

The way people (usually) contribute to an open source project on GitHub is using pull requests. A pull request is basically a patch which includes more information and allows members to discuss it on the website.

This tutorial will guide you through the whole process to generate a pull request for a project.

## 1. Chose the project you want to contribute to

If you decided to contribute to an open source project on GitHub it’s probably because you’ve been using that project and you found a bug or had an idea for a new feature.

You can also [explore featured and trending projects](https://github.com/explore) on GitHub or use the website search to find something in particular. When deciding to contribute to an open source project make sure to check it’s still active otherwise your work might remain a pull request forever.

If you don’t have a feature or bugfix in mind you can check out the _issues_ section of a project to find open tasks. It’s often useful to filter them using the labels created by the mantainers to find out available tasks not assigned to anyone yet.

![GitHub project issues](http://blog.davidecoppola.com/wp-content/uploads/2016/11/GitHub_project_issues.png "GitHub project issues")

Sometimes mantainers highlight easy tasks to encourage new contributors to join the project, like for example the one tagged “easy fix” in libgit2.

## 2. Check out how to contribute

This is a very important step as it will avoid you (and the project mantainers) to waste a lot of time trying to help a project in a wrong way.

For example some popular projects like the Linux kernel and git use GitHub as a mirror, but they don’t consider any contribution received on GitHub.

Once you are on the main page of the project you want to contribute to look for notes and files that explain how the mantainers expect you contribute to the project.

![how to contribute](http://blog.davidecoppola.com/wp-content/uploads/2016/11/howto_contribute.png "how to contribute")

Often there’s a dedicated file with detailed instruction called CONTRIBUTING.md, but sometimes you’ll find notes in the README.md file which is displayed at the bottom of the page as well.

Before starting to work on your contribution, It’s a good idea to check out existing (open) issues and pull requests to be sure you’re not going to do something which is already being done by someone else.

## 3. Fork the project

Once you have established that the project accepts pull requests and that your feature/bugfix has not already been taken, it’s time to fork the project.

Forking the project creates a personal copy which will appear in your GitHub profile. to fork a project on GitHub simply click the Fork button on the top-right corner of a project page.

![fork GitHub project](http://blog.davidecoppola.com/wp-content/uploads/2016/11/fork_GitHub_project.png "fork GitHub project")

## 4. Clone the forked project

After you forked a project you need to clone it to have a copy on your machine you can work on.

To clone a forked project go to the _repositories_ section of your GitHub profile and open it. There you can click on the “clone or download” button to get the address to clone.

![GitHub project clone or download button](http://blog.davidecoppola.com/wp-content/uploads/2016/11/GitHub-clone_or_download_button.png "GitHub project clone or download button")

GitHub gives you 2 protocols to clone a project: HTTPS and SSH. For more details about which one to use check out their detailed [guide](https://help.github.com/articles/which-remote-url-should-i-use/) on the topic. From now on let’s assume you decided to use HTTPS.

Once you have copied an URL you can clone the project using a git client or git in your shell:

<pre data-original-code="$ git clone https://github.com/YOUR_USERNAME/PROJECT.git" data-snippet-id="ext.7a82014300e20fac8f611e928a737197" data-snippet-saved="false" data-codota-status="done">
$ git clone https://github.com/YOUR_USERNAME/PROJECT.git
</pre>

Cloning a project will create a directory on your disk which contains the project and all the files used by git to keep track of it.

## 5. Set up your cloned fork

Enter the cloned directory and add the URL of the original project to your local repository so that you will be able to pull changes from it:

<pre data-original-code="$ git remote add upstream https://github.com/PROJECT_USERNAME/PROJECT.git" data-snippet-id="ext.b16852d6cd8a22a3b1400e2a389b3f2a" data-snippet-saved="false" data-codota-status="done">
$ git remote add upstream https://github.com/PROJECT_USERNAME/PROJECT.git
</pre>

I used _upstream_ as remote repository name because it’s a convention for GitHub projects, but you can use any name you want.

Now listing the remote repositories will show something like:

<pre data-original-code="$ git remote -v
origin https://github.com/YOUR_USERNAME/PROJECT.git (fetch)
origin https://github.com/YOUR_USERNAME/PROJECT.git (push)
upstream https://github.com/PROJECT_USERNAME/PROJECT.git (fetch)
upstream https://github.com/PROJECT_USERNAME/PROJECT.git (push)
" data-snippet-id="ext.20bdc46b8ecc656151ccefac2ea50056" data-snippet-saved="false" data-codota-status="done">
$ git remote -v
origin https://github.com/YOUR_USERNAME/PROJECT.git (fetch)
origin https://github.com/YOUR_USERNAME/PROJECT.git (push)
upstream https://github.com/PROJECT_USERNAME/PROJECT.git (fetch)
upstream https://github.com/PROJECT_USERNAME/PROJECT.git (push)
</pre>

## 6. Create a branch

Before starting to work on your feature or bugfix you need to create a local branch where to keep all your work. You can do that with the following git command:

$ git checkout -b BRANCH_NAME

This will create a new branch and will make it the active one in your local repository. Be sure to use a descriptive name for the branch name.

You can check you are in the right branch using git:

<pre>
$ git branch
  master
* BRANCH_NAME
</pre>

The current active branch is the one with a * on the left.

## 7. Work on your contribution

Now it’s time to work on the project. It’s very important you keep this very specific and focused on a single feature or bugfix. Trying to squeeze multiple contributions in a single pull request means chaos because it makes it impossible to handle them separately.

While working on your contribution make sure to pull changes from _upstream_ (the original project) frequently or at least before pushing your changes to _origin_ (your fork). That will force you to fix any possible conflict before submitting your pull request to the project.

## 8. Create a pull request

Once you finished to work on your contribution it’s time to push it to your forked repository on GitHub:

<pre>
$ git push origin BRANCH_NAME
</pre>

Now go back to your forked project on GitHub in your browser and you will find a new button at the top of the page to create a pull request:

![GitHub compare & pull request button](http://blog.davidecoppola.com/wp-content/uploads/2016/11/GitHub-compare_and_pull_request_button.png)

Click the button and you will get a new page which contains all the information on your pull request and where you can submit it to the original project.

Before finalising the pull request make sure to have checked everything is fine and to include as much information as possible to help the mantainers of the project understand what you have done and why.

## 9. Follow up

Hopefully some of the project mantainers will check your pull request and will give you feedback or notify you they decided to merge your changes soon. They might also ask you to change something or decide not to use your contribution. Anyway everything will be discussed on GitHub and you will receive notifications via email every time someone comments your pull request.

## 10. Clean up

After your contribution has been merged to the main project (or rejected) you can delete the branch you used for it.

To delete the branch in your local repository:

<pre>
git branch -D BRANCH_NAME
</pre>

To delete the branch on GitHub:

<pre>
git push origin --delete BRANCH_NAME
</pre>

<!-- DC responsive in page -->
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-2791567877323792" data-ad-slot="7364582061" data-ad-format="auto"></ins>

## Conclusion

I hope you enjoyed this tutorial explaining how to contribute to an open source project on GitHub. If you have any question feel free to leave a comment.

If you found it useful feel free to share it on social media using the social buttons below.

Also, don’t forget to subscribe to the blog [newsletter](http://eepurl.com/cm2cr9) to get notified of future posts.
