---
layout: post
comments: true
title: [Stealth Company At Expa]
---

[Stealth Company At Expa](https://remoteok.io/remote-startups/stealth-company-at-expa)

[Devops](https://remoteok.io/remote-devops-jobs "Remote Devops Jobs"), [Ruby](https://remoteok.io/remote-ruby-jobs "Remote Ruby Jobs"), [Engineer](https://remoteok.io/remote-engineer-jobs "Remote Engineer Jobs")

**JOB SUMMARY**


We're looking for an experienced Rails developer with DevOps skills to join our pre-launch knowledge management startup. You'll be employee number three on a **fully distributed team**. We emphasize collaboration, self-directedness, and an interest in taking on many roles within the team.


We're pre-launch and pre-name, but funded.


**RESPONSIBILITIES**


* Optimize the existing Rails code base to scale from dozens of users to thousands.
* Make search lightning fast.
* Build and own tools for provisioning, automation, configuration, integration, deployment and release processes.
* Improve the health and availability of our systems through alerting, monitoring, instrumenting, and reporting.
* Measure and improve the performance of our stack through benchmarks, capacity estimation, and troubleshooting.
* Identify and assess new technologies that improve the functionality, effectiveness, and reliability of our systems.
* Collaborate effectively with team members in different time zones and with different skill sets.

  ****

**QUALIFICATIONS**

  ****

* BA/BS in Computer Science or related field preferred
* 2+ years building products for consumer applications preferred
* Able to make solid technical judgements and back them up articulately in writing (because we're distributed and work asynchronously, we communicate primarily through writing)
* Rails experience
* ElasticSearch experience
* Ember experience a plus
* Strong Linux administration and network troubleshooting skills (preferably Ubuntu)
* Implemented and supported user-facing, large-scale, secure tech stacks on AWS; familiar with some subset of OpsWorks, S3, EC2, Route53, VPC, Salt/Chef/Puppet/Ansible config management


We believe that distributed teams are effective and inclusive teams. If you are excited about joining a small, hard working team but don't know if your experience matches what we're looking for, please get in touch with me anyway.

**To apply:** Send a resume and note to [bcohen@expa.com](mailto:%62%63%6f%68%65%6e@%65%78%70%61.%63%6f%6d)

