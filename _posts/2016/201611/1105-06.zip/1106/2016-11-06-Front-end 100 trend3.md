---
layout: post
comments: true
title: Front-end 100 trend
---

# 前端 TOP 100

[__ 热门](https://www.awesomes.cn/rank?sort=hot)[__ 趋势](https://www.awesomes.cn/rank?sort=trend)

<canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="2018" height="798"></canvas>

[![](http://awesomes.img-cn-beijing.aliyuncs.com/repo/161027220009-65-1.png@1e_1c_0o_0l_300h_300w_90q.src)

###             flv.js


B 站开源的 HTML5 播放器内核，纯 JavaScript 实现，告别 Flash

        ](https://www.awesomes.cn/repo/Bilibili/flv-js)[

2
          ![](http://awesomes.img-cn-beijing.aliyuncs.com/repo/151011135942-0-1.jpg@1e_300w_207h_1c_0i_1o_1x.png)

###               vue

一个用以创建用户接口的直观、快速、简洁的 MVVM 框架


        ](https://www.awesomes.cn/repo/yyx990803/vue)[

3
          ![](http://awesomes.img-cn-beijing.aliyuncs.com/repo/161025002222-4-1.png@1e_300w_207h_1c_0i_1o_1x.png)

###               yarn

一个用于替代 NPM 的 CLI 工具，具有快速、可信赖、安全等特点


        ](https://www.awesomes.cn/repo/yarnpkg/yarn)[

4
          ![](http://awesomes.img-cn-beijing.aliyuncs.com/repo/151011005628-65-1.jpg@1e_300w_207h_1c_0i_1o_1x.png)

###               react

Facebook 推出的一款声明式的，高效的，灵活的用于创建用户接口的JavaScript 库


        ](https://www.awesomes.cn/repo/facebook/react)[

5
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               gatsby

Transform plain text into dynamic blogs and websites using React.js


        ](https://www.awesomes.cn/repo/gatsbyjs/gatsby)[

6
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               weex

阿里推出的跨平台的移动端开发框架，具有轻量级、可扩展和高性能的特点


        ](https://www.awesomes.cn/repo/alibaba/weex)[

7
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               react-native

一个基于 React 的创建原生APP的框架


        ](https://www.awesomes.cn/repo/facebook/react-native)[

8
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               webpack

A bundler for javascript and friends. Packs many modules into a few bundled assets. Code Splitting allows to load parts for the application on demand. Through "loaders" modules can be CommonJs, AMD, ES6 modules, CSS, Images, JSON, Coffeescript, LESS, ... and your custom stuff.


        ](https://www.awesomes.cn/repo/webpack/webpack)[

9
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               bootstrap

目前最流行的 HTML, CSS 和 JavaScript 框架，用于开发响应式，移动端先行的 web 项目


        ](https://www.awesomes.cn/repo/twbs/bootstrap)[

10
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               Fuse

JavaScript 轻量级模糊搜索引擎


        ](https://www.awesomes.cn/repo/krisk/fuse)[

11
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               javascript

JavaScript 风格指南


        ](https://www.awesomes.cn/repo/airbnb/javascript)[

12
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               redux

Predictable state container for JavaScript apps


        ](https://www.awesomes.cn/repo/rackt/redux)[

13
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               d3

一个针对 HTML 和 SVG 的 JavaScript 可视化库


        ](https://www.awesomes.cn/repo/mbostock/d3)[

14
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               angular.js

Google推出的MVVM框架


        ](https://www.awesomes.cn/repo/angular/angular-js)[

15
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               three.js

JavaScript 3D 库


        ](https://www.awesomes.cn/repo/mrdoob/three-js)[

16
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               clipboard.js

在浏览器中复制文本到剪贴板的插件，不需要Flash，仅仅只有 2kb 大小


        ](https://www.awesomes.cn/repo/zenorocha/clipboard-js)[

17
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               animate.css

跨浏览器的CSS3动画库，使用方便


        ](https://www.awesomes.cn/repo/daneden/animate-css)[

18
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               element

饿了么前端推出的基于 Vue.js 2.0 的后台组件库，它能够帮助你更轻松更快速地开发后台项目。


        ](https://www.awesomes.cn/repo/ElemeFE/element)[

19
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               weui

由微信官方设计团队为微信 Web 开发量身打造的框架，包含移动web应用开发中有用的组件和模块


        ](https://www.awesomes.cn/repo/weui/weui)[

20
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               material-ui

集成 Google Material 设计的 React  组件


        ](https://www.awesomes.cn/repo/callemall/material-ui)[

21
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               vuex

Vuex 是一个专门为 Vue.js 应用所设计的集中式状态管理架构。它借鉴了 Flux 和 Redux 的设计思想，但简化了概念，并且采用了一种为能更好发挥 Vue.js 数据响应机制而专门设计的实现


        ](https://www.awesomes.cn/repo/vuejs/vuex)[

22
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               material-design-lite

Material Design Lite Components in HTML/CSS/JS


        ](https://www.awesomes.cn/repo/google/material-design-lite)[

23
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               Font-Awesome

图标字体和 CSS 套件


        ](https://www.awesomes.cn/repo/FortAwesome/font-awesome)[

24
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               ant-design

A design language


        ](https://www.awesomes.cn/repo/ant-design/ant-design)[

25
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               layui

经典模块化前端UI框架


        ](https://www.awesomes.cn/repo/sentsin/layui)[

26
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               Chart.js

使用<canvas> 标签的简洁的HTML5图表


        ](https://www.awesomes.cn/repo/nnnick/chart-js)[

27
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               AdminLTE

非常流行的基于 Bootstrap 3.x 的免费的后台UI框架


        ](https://www.awesomes.cn/repo/almasaeed2010/adminlte)[

28
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               Semantic-UI

Semantic 是一个 UI 组件框架


        ](https://www.awesomes.cn/repo/Semantic-Org/semantic-ui)[

29
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               ionic

领先的HTML5 移动开发框架和 SDK，利用你所熟知的web 技术构建难以置信的移动应用，是AngularJS最好的朋友。


        ](https://www.awesomes.cn/repo/driftyco/ionic)[

30
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               gulp

简单易用的流式构建系统


        ](https://www.awesomes.cn/repo/gulpjs/gulp)[

31
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               materialize

一个基于 Material Design 的 CSS  框架


        ](https://www.awesomes.cn/repo/Dogfalo/materialize)[

32
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               Mock

A simulation data generator


        ](https://www.awesomes.cn/repo/nuysoft/mock)[

33
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               lodash

A JavaScript utility library delivering consistency, modularity, performance, & extras.


        ](https://www.awesomes.cn/repo/lodash/lodash)[

34
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               echarts

百度团队开发的一款商业级数据图表


        ](https://www.awesomes.cn/repo/ecomfe/echarts)[

35
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               babel

Babel is a compiler for writing next generation JavaScript.


        ](https://www.awesomes.cn/repo/babel/babel)[

36
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               reveal.js

一个专门用来做 HTML 演示文稿的框架


        ](https://www.awesomes.cn/repo/hakimel/reveal-js)[

37
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               gentelella

Free Bootstrap 3 Admin Template


        ](https://www.awesomes.cn/repo/puikinsh/gentelella)[

38
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               material-design-icons

Google 开发的 Material Design 风格的图标


        ](https://www.awesomes.cn/repo/google/material-design-icons)[

39
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               moment

javascript 解析，验证，操作，和展示日期


        ](https://www.awesomes.cn/repo/moment/moment)[

40
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               phantomjs

Scriptable Headless WebKit


        ](https://www.awesomes.cn/repo/ariya/phantomjs)[

41
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               jquery

一个非常流行的操作Dom的 JavaScript  库


        ](https://www.awesomes.cn/repo/jquery/jquery)[

42
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               normalize.css

预设的一组实用的标准化样式


        ](https://www.awesomes.cn/repo/necolas/normalize-css)[

43
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               vux

基于 Vue 和 Weui 的移动端框架


        ](https://www.awesomes.cn/repo/airyland/vux)[

44
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               vue-resource

Vue.js 的 HTTP 客户端


        ](https://www.awesomes.cn/repo/vuejs/vue-resource)[

45
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               anime

一个轻量级的 Javascript  动画引擎


        ](https://www.awesomes.cn/repo/juliangarnier/anime)[

46
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               Swiper

Most modern mobile touch slider with hardware accelerated transitions


        ](https://www.awesomes.cn/repo/nolimits4web/swiper)[

47
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               vue-router

Vue.js 的官方路由


        ](https://www.awesomes.cn/repo/vuejs/vue-router)[

48
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               ng2-admin

Angular 2 admin panel framework http://akveo.com/ng2-admin/


        ](https://www.awesomes.cn/repo/akveo/ng2-admin)[

49
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               Sortable

一个简约的 JavaScript  库用于在现代浏览器中拖放列表重新排序 ，支持任何JS框架


        ](https://www.awesomes.cn/repo/RubaXa/sortable)[

50
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               mui

最接近原生APP体验的高性能框架


        ](https://www.awesomes.cn/repo/dcloudio/mui)[

51
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               bulma

基于 Flexbox 的当代 CSS 框架


        ](https://www.awesomes.cn/repo/jgthms/bulma)[

52
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               html5-boilerplate

一个用来构建快速、强大、可适配的 web app 的前端模板


        ](https://www.awesomes.cn/repo/h5bp/html5-boilerplate)[

53
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               EvaporateJS

Javascript library for browser to S3 multipart resumable uploads


        ](https://www.awesomes.cn/repo/TTLabs/evaporatejs)[

54
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               video.js

Video.js - 开源的 HTMl5 和 Flash 视频播放器


        ](https://www.awesomes.cn/repo/videojs/video-js)[

55
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               react-bootstrap

基于 React 的 Bootstrap 3  组件


        ](https://www.awesomes.cn/repo/react-bootstrap/react-bootstrap)[

56
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               immutable-js

Immutable persistent data collections for Javascript which increase efficiency and simplicity.


        ](https://www.awesomes.cn/repo/facebook/immutable-js)[

57
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               jest

Facebook 推出的基于 Jasmine  的 JavaScript  测试框架


        ](https://www.awesomes.cn/repo/facebook/jest)[

58
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               draft-js

Facebook推出的在React中创建富文本编辑器的解决方案，更多地是一个原型，所以支持深度定制


        ](https://www.awesomes.cn/repo/facebook/draft-js)[

59
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               nightmare

A high-level browser automation library.


        ](https://www.awesomes.cn/repo/segmentio/nightmare)[

60
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               npm

javascript 最流行的包管理器


        ](https://www.awesomes.cn/repo/npm/npm)[

61
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               polymer

Build modern apps using web components


        ](https://www.awesomes.cn/repo/Polymer/polymer)[

62
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               jQuery-File-Upload

一个有功能强大的 jQuery 上传组件，支持多文件选择、拖拽上传、验证、图片和多媒体预览等功能


        ](https://www.awesomes.cn/repo/blueimp/jquery-file-upload)[

63
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               dva

基于 React 和 redux 的轻量级框架


        ](https://www.awesomes.cn/repo/dvajs/dva)[

64
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               aframe

用于构建 Web VR 的 JS 库


        ](https://www.awesomes.cn/repo/aframevr/aframe)[

65
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               rollup

Next-generation ES6 module bundler


        ](https://www.awesomes.cn/repo/rollup/rollup)[

66
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               Leaflet

移动端友好的交互式地图 JavaScript 库


        ](https://www.awesomes.cn/repo/Leaflet/leaflet)[

67
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               mocha

mocha - simple, flexible, fun javascript test framework for node.js & the browser. (BDD, TDD, QUnit styles via interfaces)


        ](https://www.awesomes.cn/repo/mochajs/mocha)[

68
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               Hover

CSS3鼠标移到元素上面的动画效果，可运用在超链接、按钮、logo、SVG、图片等等。能够很方便地使用在你自己的元素上,支持 CSS、Sass、LESS


        ](https://www.awesomes.cn/repo/IanLunn/hover)[

69
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               mint-ui

基于 vue.js 的移动端 UI 框架


        ](https://www.awesomes.cn/repo/ElemeFE/mint-ui)[

70
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               vue-admin

一个 Vue 后台控制面板


        ](https://www.awesomes.cn/repo/fundon/vue-admin)[

71
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               lib-flexible

可伸缩布局方案


        ](https://www.awesomes.cn/repo/amfe/lib-flexible)[

72
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               react-toolbox

一系列集成 Material 设计风格和 CSS 模块的 React  组件


        ](https://www.awesomes.cn/repo/react-toolbox/react-toolbox)[

73
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               postcss

Transforming styles with JS plugins


        ](https://www.awesomes.cn/repo/postcss/postcss)[

74
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               pixi.js

Super fast HTML 5 2D rendering engine that uses webGL with canvas fallback


        ](https://www.awesomes.cn/repo/pixijs/pixi-js)[

75
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               quill

一个轻量级、可定制和跨浏览器的富文本编辑器


        ](https://www.awesomes.cn/repo/quilljs/quill)[

76
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               select2

Select2 is a jQuery based replacement for select boxes. It supports searching, remote data sets, and infinite scrolling of results.


        ](https://www.awesomes.cn/repo/select2/select2)[

77
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               iscroll

Smooth scrolling for the web


        ](https://www.awesomes.cn/repo/cubiq/iscroll)[

78
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               underscore

JavaScript's utility _ belt


        ](https://www.awesomes.cn/repo/jashkenas/underscore)[

79
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               vue-cli

Vue.js 简单的脚手架命令行工具


        ](https://www.awesomes.cn/repo/vuejs/vue-cli)[

80
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               pdf.js

JavaScript 的 PDF 查看器


        ](https://www.awesomes.cn/repo/mozilla/pdf-js)[

81
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               fullPage.js

fullPage plugin by Alvaro Trigo. Create full screen pages fast and simple


        ](https://www.awesomes.cn/repo/alvarotrigo/fullpage-js)[

82
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               react-select

为 React JS  打造的包含多选、自动完成、ajax 支持的下拉框


        ](https://www.awesomes.cn/repo/JedWatson/react-select)[

83
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               particles.js

A lightweight JavaScript library for creating particles


        ](https://www.awesomes.cn/repo/VincentGarreau/particles-js)[

84
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               css-modules

Documentation about css-modules


        ](https://www.awesomes.cn/repo/css-modules/css-modules)[

85
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               vue-strap

基于 Vue.js 的 Bootstrap  组件


        ](https://www.awesomes.cn/repo/yuche/vue-strap)[

86
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               standard

:star2: JavaScript Standard Style — One Style to Rule Them All


        ](https://www.awesomes.cn/repo/feross/standard)[

87
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               flow

Adds static typing to JavaScript to improve developer productivity and code quality.


        ](https://www.awesomes.cn/repo/facebook/flow)[

88
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               highlight.js

语法高亮的Javascript 插件


        ](https://www.awesomes.cn/repo/isagalaev/highlight-js)[

89
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               slick

你所需要的最后一个轮播插件


        ](https://www.awesomes.cn/repo/kenwheeler/slick)[

90
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               bootstrap-datepicker

A datepicker for @twitter bootstrap forked from Stefan Petre's (of eyecon.ro), improvements by @eternicode


        ](https://www.awesomes.cn/repo/eternicode/bootstrap-datepicker)[

91
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               blur-admin

Angular Bootstrap Admin Panel Framework


        ](https://www.awesomes.cn/repo/akveo/blur-admin)[

92
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               turbolinks

为你的 web 应用优化页面切换速度


        ](https://www.awesomes.cn/repo/turbolinks/turbolinks)[

93
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               ava

Futuristic test runner :rocket:


        ](https://www.awesomes.cn/repo/sindresorhus/ava)[

94
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               dropzone

Dropzone is an easy to use drag'n'drop library. It supports image previews and shows nice progress bars.


        ](https://www.awesomes.cn/repo/enyo/dropzone)[

95
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               graphql-js

A reference implementation of GraphQL for JavaScript


        ](https://www.awesomes.cn/repo/graphql/graphql-js)[

96
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               Aurelia

The aurelia framework brings together all the required core aurelia libraries into a ready-to-go application-building platform.


        ](https://www.awesomes.cn/repo/aurelia/framework)[

97
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               ionicons

为 Ionic 定制的优质图标库


        ](https://www.awesomes.cn/repo/driftyco/ionicons)[

98
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               OnsenUI

用来构建混合移动端APP的 HTML5 UI 框架


        ](https://www.awesomes.cn/repo/OnsenUI/onsenui)[

99
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               hammer.js

实现多点触控的javascript库


        ](https://www.awesomes.cn/repo/hammerjs/hammer-js)[

100
          ![](https://www.awesomes.cn/assets/placeholder.png)

###               phaser

Phaser is a fun, free and fast 2D game framework for making HTML5 games for desktop and mobile web browsers, supporting Canvas and WebGL rendering.


        ](https://www.awesomes.cn/repo/photonstorm/phaser)

        数据来自 [Github](http://www.github.com/) 和 [Awesomes-cn](http://www.awesomes.cn/) 每天更新

