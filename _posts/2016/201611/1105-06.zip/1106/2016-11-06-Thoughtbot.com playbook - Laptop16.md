---
layout: post
comments: true
title: Thoughtbot.com playbook - Laptop
---

Laptop is a script to set up an macOS laptop for web development.

It can be run multiple times on the same machine safely. It installs, upgrades, or skips packages based on what is already installed on the machine.



https://github.com/thoughtbot/laptop


