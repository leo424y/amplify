---
layout: post
comments: true
title: skymatters
---

由於**應聘者必須對工作英語讀寫沒有問題**, 以下內容就不準備中文版本的了, 敬請見諒.

## About Skymatters

SkyMatters specializes on the fast growing O2O digital marketing campaign and building digital activation platform, LOOP. LOOP is a unified cloud platform that enables your brand to engage with consumers quickly, inexpensively and making your products smart.

## Position Description

The position is to work with our technical director and the other software engineers on the main platform LOOP. Your primary focus will be to develop both server-side logic and client-side look and feel, and join our feature and development discussion and planning. If you are stronger or interested in either server-side or client-side, we would also consider.

By joining Skymatters development team as a key member, you will have the opportunity to work on live projects used by big corporates and millions of individuals from different countries. The team does not only deliver reliable features, but also decent code.

## Requirements

* No less than 3 years of experience in Ruby on Rails development
* Degree in computer science or software engineering is preferred but not a must
* Experience in Aliyun deployment and optimization, Wechat Official Account development and digital marketing in China is a big bonus
* Motivated individual with a strong analytical mind

## Responsibility

* Design, build and maintain efficient, reusable and reliable Ruby code
* Integrate data storage solutions, including databases and key-value stores
* Make user-friendly and responsive interface with ReactJS, Bootstrap and HTML5
* Identify system bugs and devise solutions to the problems
* Help maintain code quality, organization and automation
* Optimize applications for speed and scalability

## Benefit

* No less than RMB 20k/M for the senior role and negotiable for junior and middle level positions
* 40 hours a week, 12 days of paid leaves + Hong Kong Public Holidays (~ 17 days a year)
* Work from wherever the (real) Internet is available, unless you want to join our Hong Kong team!

## How to apply

* Qualified candidates please send your CV to hr-at-skymatters.com

注:

1.  Skymatters的產品LOOP已發佈, 但仍處於創業早期, 如果您只希望在大公司效力, 可以跳過.
2.  雖然是個遠程職位, 也接受香港辦公室的職位申請(可辦理簽證), 附辦公室環境圖一張

[](https://ruby-china-files.b0.upaiyun.com/photo/2016/dcbe1cd37f1eaf386359f8a14f715078.jpg!large)

[![](https://ruby-china-files.b0.upaiyun.com/photo/2016/dcbe1cd37f1eaf386359f8a14f715078.jpg!large)](https://ruby-china-files.b0.upaiyun.com/photo/2016/dcbe1cd37f1eaf386359f8a14f715078.jpg!large)


